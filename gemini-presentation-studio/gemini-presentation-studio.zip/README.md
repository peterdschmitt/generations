
# Gemini Presentation Studio

A professional-grade asset generation platform powered by Google's **Gemini 3 Pro** (Nano Banana Pro) and **Veo**. 

## 🚀 Quick Start (Local Setup)

If you have copied the `setup.js` file from the AI Chat:

1. **Run the Installer**:
   ```bash
   node setup.js
   ```
   This will generate all the necessary project files and folders.

2. **Install Dependencies**:
   ```bash
   npm install
   ```

3. **Start the App**:
   ```bash
   npm run dev
   ```

## Features

- **Nano Banana Pro Integration**: Access the `gemini-3-pro-image-preview` model.
- **Smart Prompt Synthesizer**: Converts simple inputs into professional prompts.
- **Airtable Integration**: Auto-save metadata and bridge images to the cloud via ImgBB.
- **Local Persistence**: Images are instantly saved to your browser's IndexedDB.

## Configuration

Click the **Settings (Gear Icon)** in the top right to configure:

1. **Airtable**:
   - **Base ID**: The ID of your Airtable Base.
   - **API Key**: A Personal Access Token (PAT).
2. **ImgBB (Optional)**:
   - Add a free API key to enable automatic image uploading.
