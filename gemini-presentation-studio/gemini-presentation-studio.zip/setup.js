
const fs = require('fs');
const path = require('path');

const files = {
  'package.json': `{
  "name": "gemini-presentation-studio",
  "version": "1.0.0",
  "description": "Professional asset generator using Gemini 3 Pro and Veo",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "@google/genai": "^1.29.0",
    "lucide-react": "^0.263.1",
    "clsx": "^2.0.0",
    "tailwind-merge": "^1.14.0"
  },
  "devDependencies": {
    "@types/react": "^18.2.15",
    "@types/react-dom": "^18.2.7",
    "@vitejs/plugin-react": "^4.0.0",
    "typescript": "^5.0.2",
    "vite": "^4.3.9",
    "autoprefixer": "^10.4.14",
    "postcss": "^8.4.24",
    "tailwindcss": "^3.3.2"
  }
}`,

  'vite.config.ts': `import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
})`,

  '.gitignore': `# Logs
logs
*.log
npm-debug.log*
yarn-debug.log*
yarn-error.log*
pnpm-debug.log*
lerna-debug.log*

# node_modules
node_modules
dist
dist-ssr
*.local

# Editor directories and files
.vscode/*
!.vscode/extensions.json
.idea
.DS_Store
*.suo
*.ntvs
*.njsproj
*.sln
*.sw?

# Environment variables
.env
.env.test
.env.production`,

  'index.html': `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Gemini Presentation Studio</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
      tailwind.config = {
        darkMode: 'class',
        theme: {
          extend: {
            colors: {
              'primary': '#7c3aed',
              'primary-hover': '#6d28d9',
              'primary-light': '#a78bfa',
            }
          }
        }
      }
    </script>
  </head>
  <body class="bg-gray-900 text-gray-100">
    <div id="root"></div>
    <script type="module" src="/index.tsx"></script>
  </body>
</html>`,

  'index.tsx': `import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);`,

  'metadata.json': `{
  "name": "Gemini Presentation Studio",
  "description": "Create professional assets for your presentations with Gemini Presentation Studio. Generate high-quality 2K/4K images and videos using the power of Gemini 3 Pro and Veo.",
  "requestFramePermissions": []
}`,

  'services/airtableService.ts': `
export interface AirtableConfig {
    apiKey: string;
    baseId: string;
    tableName: string;
    imgbbApiKey?: string;
}

export interface ThemeRecord {
    id: string;
    name: string;
    prompt: string;
}

export interface ControlRecord {
    id: string;
    label: string;
    value: string;
    category: 'Layout' | 'Style' | 'Lighting' | 'Camera';
}

export interface TemplateRecord {
    id: string;
    title: string;
    description: string;
    prompt: string;
    category: string;
}

// Helper to upload base64 to ImgBB and get a public URL
// Now returns an object with success/url or error message
const uploadToImageHost = async (apiKey: string, base64Image: string): Promise<{ url: string | null; error?: string }> => {
    try {
        const formData = new FormData();
        const cleanBase64 = base64Image.replace(/^data:image\\/[a-zA-Z]+;base64,/, "");
        formData.append("image", cleanBase64);
        formData.append("name", \`gen-\${Date.now()}.png\`);

        const response = await fetch(\`https://api.imgbb.com/1/upload?key=\${apiKey}\`, {
            method: "POST",
            body: formData,
        });

        if (!response.ok) {
            const errText = await response.text();
            let msg = \`HTTP \${response.status}\`;
            try {
                const errJson = JSON.parse(errText);
                if (errJson.error && errJson.error.message) msg = errJson.error.message;
            } catch (e) {}
            return { url: null, error: msg };
        }

        const data = await response.json();
        if (data.success && data.data && data.data.url) {
            return { url: data.data.url };
        }
        return { url: null, error: "ImgBB response missing URL" };
    } catch (e: any) {
        return { url: null, error: e.message || "Network error bridging to ImgBB" };
    }
};

export const saveRecordToAirtable = async (
    config: AirtableConfig,
    data: {
        prompt: string;
        type: 'image' | 'video';
        topic?: string;
        campaign?: string;
        style?: string;
        layout?: string;
        aspectRatio?: string;
        resolution?: string;
        isFavorite?: boolean;
        imageData?: string | null;
        lighting?: string;
        camera?: string;
        rawInput?: string;
        creativeDirection?: string;
        templateId?: string;
    }
): Promise<string> => {
    const url = \`https://api.airtable.com/v0/\${config.baseId}/\${encodeURIComponent(config.tableName)}\`;
    const formattedType = data.type.charAt(0).toUpperCase() + data.type.slice(1);

    const metadata = {
        raw: data.rawInput,
        lit: data.lighting,
        cam: data.camera,
        cd: data.creativeDirection,
        tid: data.templateId
    };
    
    const cleanMetadata = Object.fromEntries(Object.entries(metadata).filter(([_, v]) => v != null && v !== ''));
    
    let combinedPrompt = data.prompt;
    if (Object.keys(cleanMetadata).length > 0) {
        combinedPrompt = \`\${data.prompt} ||| \${JSON.stringify(cleanMetadata)}\`;
    }

    const fields: any = {
        "Topic": data.topic || "Uncategorized",
        "Campaign": data.campaign || "General",
        "Prompt": combinedPrompt, 
        "Type": formattedType,
        "Style": data.style || "N/A",
        "Layout": data.layout || "N/A",
        "AspectRatio": data.aspectRatio || "N/A",
        "Resolution": data.resolution || "N/A",
        "Favorite": data.isFavorite ? "Yes" : "No"
    };

    let uploadError = "";

    if (config.imgbbApiKey && data.imageData && data.type === 'image') {
        const result = await uploadToImageHost(config.imgbbApiKey, data.imageData);
        if (result.url) {
            fields["Attachments"] = [{ url: result.url }];
        } else if (result.error) {
            uploadError = result.error;
            console.warn("Image bridge failed:", result.error);
        }
    }

    const payload = { fields: fields, typecast: true };

    const response = await fetch(url, {
        method: 'POST',
        headers: { 'Authorization': \`Bearer \${config.apiKey}\`, 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });

    if (!response.ok) {
        const err = await response.json();
        throw new Error(\`Airtable Error: \${err.error?.message || response.statusText}\`);
    }
    const responseData = await response.json();
    
    if (uploadError) {
        throw new Error(\`Saved to Airtable, but Image Upload Failed: \${uploadError}\`);
    }

    return responseData.id;
};

export const fetchGenerationHistory = async (config: AirtableConfig): Promise<any[]> => {
    const url = \`https://api.airtable.com/v0/\${config.baseId}/\${encodeURIComponent(config.tableName)}?maxRecords=50\`;
    const response = await fetch(url, { headers: { 'Authorization': \`Bearer \${config.apiKey}\` } });
    if (!response.ok) return [];

    const data = await response.json();
    return data.records.map((r: any) => {
        const fields = r.fields;
        let imageUrl = null;
        let videoUrl = null;
        const attachments = fields.Attachments || fields.Attachment || fields.Images || fields.Image || fields.File;

        if (attachments && Array.isArray(attachments) && attachments.length > 0) {
            const attachment = attachments[0];
            const typeLower = (fields.Type || 'image').toLowerCase();
            if (typeLower === 'video') {
                 videoUrl = attachment.url;
                 imageUrl = attachment.thumbnails?.large?.url || null; 
            } else {
                 imageUrl = attachment.url;
            }
        }

        let displayPrompt = fields.Prompt || '';
        let extendedMetadata: any = {};
        if (displayPrompt.includes(' ||| ')) {
            const parts = displayPrompt.split(' ||| ');
            displayPrompt = parts[0];
            try { extendedMetadata = JSON.parse(parts[1]); } catch (e) {}
        }

        return {
            id: r.id,
            createdTime: r.createdTime, 
            type: (fields.Type || 'image').toLowerCase(),
            topic: fields.Topic || '',
            campaign: fields.Campaign || '',
            isFavorite: fields.Favorite === 'Yes',
            prompt: displayPrompt,
            imageUrl: imageUrl, 
            videoUrl: videoUrl,
            aspectRatio: fields.AspectRatio,
            resolution: fields.Resolution,
            metadata: {
                style: fields.Style,
                layout: fields.Layout,
                lighting: extendedMetadata.lit,
                camera: extendedMetadata.cam,
                rawInput: extendedMetadata.raw,
                creativeDirection: extendedMetadata.cd,
                templateId: extendedMetadata.tid
            }
        };
    }).sort((a: any, b: any) => new Date(b.createdTime).getTime() - new Date(a.createdTime).getTime());
};

export const checkAirtableConnection = async (config: AirtableConfig): Promise<void> => {
    const url = \`https://api.airtable.com/v0/\${config.baseId}/\${encodeURIComponent(config.tableName)}?maxRecords=1\`;
    const response = await fetch(url, { headers: { 'Authorization': \`Bearer \${config.apiKey}\` } });
    if (!response.ok) throw new Error("Connection failed");
};

export const fetchThemes = async (config: AirtableConfig): Promise<ThemeRecord[]> => {
    const url = \`https://api.airtable.com/v0/\${config.baseId}/Themes\`;
    const response = await fetch(url, { headers: { 'Authorization': \`Bearer \${config.apiKey}\` } });
    if (!response.ok) return [];
    const data = await response.json();
    return data.records.map((r: any) => ({ id: r.id, name: r.fields.Name, prompt: r.fields.Prompt }));
};

export const createTheme = async (config: AirtableConfig, name: string, prompt: string): Promise<ThemeRecord> => {
    const url = \`https://api.airtable.com/v0/\${config.baseId}/Themes\`;
    const payload = { fields: { "Name": name, "Prompt": prompt }, typecast: true };
    const response = await fetch(url, { method: 'POST', headers: { 'Authorization': \`Bearer \${config.apiKey}\`, 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    if (!response.ok) throw new Error("Failed");
    const r = await response.json();
    return { id: r.id, name: r.fields.Name, prompt: r.fields.Prompt };
};

export const deleteTheme = async (config: AirtableConfig, recordId: string): Promise<void> => {
    const url = \`https://api.airtable.com/v0/\${config.baseId}/Themes/\${recordId}\`;
    await fetch(url, { method: 'DELETE', headers: { 'Authorization': \`Bearer \${config.apiKey}\` } });
};

export const fetchControls = async (config: AirtableConfig): Promise<ControlRecord[]> => {
    const url = \`https://api.airtable.com/v0/\${config.baseId}/Controls?maxRecords=100\`;
    const response = await fetch(url, { headers: { 'Authorization': \`Bearer \${config.apiKey}\` } });
    if (!response.ok) return [];
    const data = await response.json();
    return data.records.map((r: any) => ({
        id: r.id,
        label: r.fields.Label,
        value: r.fields.Value,
        category: r.fields.Category
    }));
};

export const createControl = async (config: AirtableConfig, label: string, value: string, category: string): Promise<ControlRecord> => {
    const url = \`https://api.airtable.com/v0/\${config.baseId}/Controls\`;
    const payload = { fields: { "Label": label, "Value": value, "Category": category }, typecast: true };
    const response = await fetch(url, { method: 'POST', headers: { 'Authorization': \`Bearer \${config.apiKey}\`, 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    if (!response.ok) throw new Error("Failed");
    const r = await response.json();
    return { id: r.id, label: r.fields.Label, value: r.fields.Value, category: r.fields.Category };
};

export const deleteControl = async (config: AirtableConfig, id: string): Promise<void> => {
    const url = \`https://api.airtable.com/v0/\${config.baseId}/Controls/\${id}\`;
    await fetch(url, { method: 'DELETE', headers: { 'Authorization': \`Bearer \${config.apiKey}\` } });
};

export const fetchTemplates = async (config: AirtableConfig): Promise<TemplateRecord[]> => {
    const url = \`https://api.airtable.com/v0/\${config.baseId}/Templates?maxRecords=100\`;
    const response = await fetch(url, { headers: { 'Authorization': \`Bearer \${config.apiKey}\` } });
    if (!response.ok) return [];
    const data = await response.json();
    return data.records.map((r: any) => ({
        id: r.id,
        title: r.fields.Title,
        description: r.fields.Description,
        prompt: r.fields.Prompt,
        category: r.fields.Category || 'Custom'
    }));
};

export const createTemplate = async (config: AirtableConfig, title: string, desc: string, prompt: string, cat: string): Promise<TemplateRecord> => {
    const url = \`https://api.airtable.com/v0/\${config.baseId}/Templates\`;
    const payload = { fields: { "Title": title, "Description": desc, "Prompt": prompt, "Category": cat }, typecast: true };
    const response = await fetch(url, { method: 'POST', headers: { 'Authorization': \`Bearer \${config.apiKey}\`, 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    if (!response.ok) throw new Error("Failed");
    const r = await response.json();
    return { id: r.id, title: r.fields.Title, description: r.fields.Description, prompt: r.fields.Prompt, category: r.fields.Category };
};`,

  'services/dbService.ts': `
const DB_NAME = 'GeminiStudioDB';
const DB_VERSION = 1;
const STORE_NAME = 'images';

export const initDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = (event) => reject("Could not open local database");
    request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
    request.onsuccess = (event) => resolve((event.target as IDBOpenDBRequest).result);
  });
};

export const saveLocalImage = async (id: string, dataUrl: string): Promise<void> => {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([STORE_NAME], 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.put({ id, dataUrl, timestamp: Date.now() });
    request.onsuccess = () => resolve();
    request.onerror = () => reject("Failed to save image locally");
  });
};

export const getLocalImage = async (id: string): Promise<string | null> => {
  const db = await initDB();
  return new Promise((resolve) => {
    const transaction = db.transaction([STORE_NAME], 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.get(id);
    request.onsuccess = () => {
      const result = request.result;
      resolve(result ? result.dataUrl : null);
    };
    request.onerror = () => resolve(null);
  });
};`,

  'services/geminiService.ts': `
import { GoogleGenAI, Modality, Type } from "@google/genai";

const getAiClient = () => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set. Please configure it in your environment.");
  }
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
}

const processImageResponse = (response: any): string => {
   if (response.candidates && response.candidates.length > 0) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          const base64ImageBytes: string = part.inlineData.data;
          const responseMimeType = part.inlineData.mimeType || 'image/png';
          return \`data:\${responseMimeType};base64,\${base64ImageBytes}\`;
        }
      }
  }
  throw new Error("Image generation failed or the response did not contain an image.");
}

export const editImageWithPrompt = async (
  base64ImageData: string,
  mimeType: string,
  prompt: string,
  aspectRatio: string = "1:1",
  imageSize: string = "1K"
): Promise<string> => {
  const ai = getAiClient();
  const imagePart = { inlineData: { data: base64ImageData, mimeType: mimeType } };
  const textPart = { text: prompt };
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-image-preview',
    contents: { parts: [imagePart, textPart] },
    config: {
      imageConfig: { aspectRatio: aspectRatio, imageSize: imageSize },
      responseModalities: [Modality.IMAGE],
    },
  });
  return processImageResponse(response);
};

export const generateImageFromPrompt = async (
  prompt: string,
  aspectRatio: string = "1:1",
  imageSize: string = "1K"
): Promise<string> => {
  const ai = getAiClient();
  const textPart = { text: prompt };
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-image-preview',
    contents: { parts: [textPart] },
    config: {
      imageConfig: { aspectRatio: aspectRatio, imageSize: imageSize },
      responseModalities: [Modality.IMAGE],
    },
  });
  return processImageResponse(response);
}

export const getSuggestionsForImage = async (
  base64ImageData: string,
  prompt: string
): Promise<string[]> => {
  const ai = getAiClient();
  const imagePart = { inlineData: { data: base64ImageData, mimeType: 'image/png' } };
  const textPart = { text: \`Based on the original prompt "\${prompt}", suggest 3 creative, single-sentence improvements for this image. The suggestions should be distinct and phrased as instructions to add to a prompt, for example: "add a cinematic lighting effect", "change the style to vaporwave", or "make the cat wear a tiny hat".\` };

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: { parts: [imagePart, textPart] },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          suggestions: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        }
      }
    }
  });

  try {
    const jsonString = response.text;
    const result = JSON.parse(jsonString);
    if (result.suggestions && Array.isArray(result.suggestions)) {
      return result.suggestions.slice(0, 3);
    }
  } catch(e) {
    console.error("Error parsing suggestions JSON:", e);
  }
  return [];
};

export const generateVideoFromPrompt = async (
  prompt: string,
  onProgress: (message: string) => void,
  startImage: { mimeType: string, data: string } | null,
  aspectRatio: '16:9' | '9:16',
  resolution: '720p' | '1080p'
): Promise<string> => {
  const ai = getAiClient();
  onProgress("Starting video generation...");

  const requestPayload: any = {
    model: 'veo-3.1-fast-generate-preview',
    prompt: prompt,
    config: { numberOfVideos: 1, resolution: resolution, aspectRatio: aspectRatio }
  };

  if (startImage) {
    requestPayload.image = { imageBytes: startImage.data, mimeType: startImage.mimeType };
  }
  
  let operation = await ai.models.generateVideos(requestPayload);
  onProgress("Video is processing... this may take a few minutes.");

  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 10000));
    operation = await ai.operations.getVideosOperation({ operation: operation });
    onProgress("Still working... hang tight!");
  }

  onProgress("Finalizing video...");
  const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
  if (!downloadLink) throw new Error("Video generation completed, but no download link was found.");

  onProgress("Downloading your video...");
  const response = await fetch(\`\${downloadLink}&key=\${process.env.API_KEY}\`);
  if (!response.ok) throw new Error(\`Failed to download video: \${response.statusText}\`);
  
  const videoBlob = await response.blob();
  return URL.createObjectURL(videoBlob);
}`,

  'components/ControlManagerModal.tsx': `
import React, { useState, useEffect } from 'react';
import Icon from './Icon';
import { AirtableConfig, fetchControls, createControl, deleteControl, ControlRecord } from '../services/airtableService';
import Spinner from './Spinner';

interface ControlManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: AirtableConfig;
  onUpdate: () => void;
}

const CATEGORIES = ['Layout', 'Style', 'Lighting', 'Camera'];

const ControlManagerModal: React.FC<ControlManagerModalProps> = ({ isOpen, onClose, config, onUpdate }) => {
  const [controls, setControls] = useState<ControlRecord[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('Layout');
  const [newLabel, setNewLabel] = useState('');
  const [newValue, setNewValue] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (isOpen) loadControls();
  }, [isOpen, config]);

  const loadControls = async () => {
    setIsLoading(true);
    try {
        const data = await fetchControls(config);
        setControls(data);
    } catch (e) {
        console.error("Failed to load controls", e);
    } finally {
        setIsLoading(false);
    }
  };

  const handleAdd = async () => {
      if (!newLabel || !newValue) return;
      setIsSaving(true);
      try {
          const newItem = await createControl(config, newLabel, newValue, activeTab);
          setControls(prev => [...prev, newItem]);
          setNewLabel('');
          setNewValue('');
          onUpdate();
      } catch (e) {
          alert("Failed to add control. Check Airtable 'Controls' table exists.");
      } finally {
          setIsSaving(false);
      }
  };

  const handleDelete = async (id: string) => {
      if (!confirm("Delete this option?")) return;
      try {
          await deleteControl(config, id);
          setControls(prev => prev.filter(c => c.id !== id));
          onUpdate();
      } catch (e) {
          alert("Failed to delete.");
      }
  };

  if (!isOpen) return null;
  const filteredControls = controls.filter(c => c.category === activeTab);

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-gray-800 rounded-xl border border-gray-700 w-full max-w-2xl h-[70vh] flex flex-col shadow-2xl">
        <div className="bg-gray-900/50 p-4 border-b border-gray-700 flex justify-between items-center">
            <h3 className="text-lg font-bold text-white flex items-center gap-2"><Icon name="settings" className="w-5 h-5 text-primary" /> Manage Studio Controls</h3>
            <button onClick={onClose} className="text-gray-400 hover:text-white"><Icon name="close" className="w-5 h-5" /></button>
        </div>
        <div className="flex border-b border-gray-700 bg-gray-900/30">
            {CATEGORIES.map(cat => (
                <button key={cat} onClick={() => setActiveTab(cat)} className={\`flex-1 py-3 text-sm font-medium \${activeTab === cat ? 'text-primary border-b-2 border-primary bg-primary/5' : 'text-gray-400 hover:text-white'}\`}>{cat}</button>
            ))}
        </div>
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
             <div className="bg-gray-700/30 p-4 rounded-lg border border-gray-600 grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
                 <div className="sm:col-span-5">
                     <label className="text-[10px] uppercase text-gray-500 font-bold block mb-1">Label</label>
                     <input type="text" value={newLabel} onChange={e => setNewLabel(e.target.value)} placeholder="e.g. Neon Noir" className="w-full bg-gray-900 border border-gray-600 rounded px-2 py-1.5 text-sm text-white focus:border-primary outline-none" />
                 </div>
                 <div className="sm:col-span-5">
                     <label className="text-[10px] uppercase text-gray-500 font-bold block mb-1">Value</label>
                     <input type="text" value={newValue} onChange={e => setNewValue(e.target.value)} placeholder="e.g. High contrast neon lighting" className="w-full bg-gray-900 border border-gray-600 rounded px-2 py-1.5 text-sm text-white focus:border-primary outline-none" />
                 </div>
                 <div className="sm:col-span-2">
                     <button onClick={handleAdd} disabled={isSaving || !newLabel} className="w-full bg-primary hover:bg-primary-hover text-white py-1.5 rounded text-sm font-bold flex justify-center">{isSaving ? <Spinner /> : 'Add'}</button>
                 </div>
             </div>
             {isLoading ? <div className="text-center py-4"><Spinner /></div> : (
                 <div className="space-y-2">
                     {filteredControls.map(c => (
                         <div key={c.id} className="flex items-center justify-between p-3 bg-gray-800 border border-gray-700 rounded hover:border-gray-500">
                             <div>
                                 <div className="font-bold text-sm text-gray-200">{c.label}</div>
                                 <div className="text-xs text-gray-500">{c.value}</div>
                             </div>
                             <button onClick={() => handleDelete(c.id)} className="text-red-400 hover:bg-red-900/30 p-1.5 rounded transition-colors"><Icon name="close" className="w-4 h-4" /></button>
                         </div>
                     ))}
                     {filteredControls.length === 0 && <div className="text-center text-gray-500 text-sm py-4 italic">No custom controls found.</div>}
                 </div>
             )}
        </div>
      </div>
    </div>
  );
};
export default ControlManagerModal;`,

  'components/ControlSelect.tsx': `
import React from 'react';

interface ControlSelectProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: { value: string; label: string }[];
  disabled?: boolean;
}

const ControlSelect: React.FC<ControlSelectProps> = ({ label, value, onChange, options, disabled }) => {
  return (
    <div className="min-w-[120px] flex-1">
      <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
        {label}
      </label>
      <div className="relative">
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          disabled={disabled}
          className="w-full appearance-none bg-gray-900 border border-gray-700 text-gray-300 text-sm rounded shadow-sm focus:ring-1 focus:ring-primary focus:border-primary block p-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {options.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-500">
          <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
            <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
          </svg>
        </div>
      </div>
    </div>
  );
};
export default ControlSelect;`,

  'components/CreativeDirectionManager.tsx': `
import React, { useState, useEffect } from 'react';
import Icon from './Icon';
import { ThemeRecord, fetchThemes, createTheme, deleteTheme, AirtableConfig } from '../services/airtableService';

const DEFAULT_THEMES: ThemeRecord[] = [
    { id: 'def-style-1', name: 'Modern SaaS Vector', prompt: 'Generate a flat vector illustration in a modern SaaS landing‑page style, no gradients, minimal shading.' },
    { id: 'def-style-2', name: 'Corporate Blue Palette', prompt: 'Use a limited palette of navy, cyan, and white only, with navy as the background and cyan for highlights.' },
    { id: 'def-style-3', name: 'Bright & Optimistic', prompt: 'Make the overall mood bright and optimistic, with lots of light and open space, avoiding dark or gloomy tones.' },
    { id: 'def-photo-1', name: 'Corporate Headshot', prompt: 'Show a close‑up portrait from the shoulders up, camera at eye level, with very little background visible. Light the scene with warm golden‑hour sunlight.' },
    { id: 'def-photo-2', name: 'Golden Hour Realism', prompt: 'Light the scene with warm golden‑hour sunlight from the left, with soft, natural shadows on the right.' },
    { id: 'def-photo-3', name: 'Cinematic 35mm Lens', prompt: 'Render this as if shot with a 35mm lens, slightly wide, with shallow depth of field and strong bokeh in the background.' },
    { id: 'def-photo-4', name: 'Product Focal Point', prompt: 'Place the main product in the exact center, large, with the background softly blurred so nothing distracts from it.' },
    { id: 'def-layout-1', name: 'YouTube Thumbnail (16:9)', prompt: 'Create a 16:9 YouTube thumbnail with plenty of negative space on the right for text.' },
    { id: 'def-layout-2', name: 'Vertical Poster', prompt: 'Create a vertical poster with a large hero image on top, headline in the middle, and call‑to‑action button at the bottom.' },
    { id: 'def-layout-3', name: 'Presentation Title Slide', prompt: 'Design a presentation title slide: large centered headline at top, smaller subtitle underneath, and a subtle abstract background.' },
    { id: 'def-ui-1', name: 'Dashboard UI Mockup', prompt: 'Mock up a SaaS analytics dashboard with a top nav, left sidebar, and three main metric cards in the center.' },
    { id: 'def-data-1', name: 'Infographic Funnel', prompt: 'Design a 16:9 infographic explaining our 3‑step funnel. Use three big numbered sections with short labels and matching icons.' },
    { id: 'def-data-2', name: 'Minimal Bar Chart', prompt: 'Draw a clean, minimal bar chart with 4 bars showing a steady upward trend; use brand colors only.' },
    { id: 'def-data-3', name: 'Flowchart (5-Step)', prompt: 'Create a left‑to‑right flowchart with 5 boxes connected by arrows, each box having a short, readable label.' },
    { id: 'def-anim-1', name: 'Animation Keyframes (Zoom)', prompt: 'Produce 4 keyframe images of this subject: frame 1 small and distant, frame 4 very large close‑up, so they can be animated as a zoom‑in.' },
];

interface CreativeDirectionManagerProps {
    config: AirtableConfig;
    selectedThemePrompt: string;
    onSelect: (prompt: string) => void;
}

const CreativeDirectionManager: React.FC<CreativeDirectionManagerProps> = ({ config, selectedThemePrompt, onSelect }) => {
    const [themes, setThemes] = useState<ThemeRecord[]>(DEFAULT_THEMES);
    const [isLoading, setIsLoading] = useState(false);
    const [showModal, setShowModal] = useState(false);
    const [newName, setNewName] = useState('');
    const [newPrompt, setNewPrompt] = useState('');
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => { loadThemes(); }, [config]);

    const loadThemes = async () => {
        setIsLoading(true);
        try {
            const remoteThemes = await fetchThemes(config);
            setThemes([...DEFAULT_THEMES, ...remoteThemes]);
        } catch (e) {
            setThemes(DEFAULT_THEMES);
        } finally {
            setIsLoading(false);
        }
    };

    const handleCreate = async () => {
        if (!newName.trim() || !newPrompt.trim()) return;
        setIsSaving(true);
        try {
            const newTheme = await createTheme(config, newName, newPrompt);
            setThemes(prev => [...prev, newTheme]);
            setNewName(''); setNewPrompt('');
            onSelect(newTheme.prompt);
        } catch (e) {
            alert("Failed to save to Airtable. Check your configuration.");
        } finally {
            setIsSaving(false);
        }
    };

    const handleDelete = async (id: string) => {
        if (id.startsWith('def-')) { alert("Cannot delete default presets."); return; }
        if (!confirm("Are you sure you want to delete this theme from Airtable?")) return;
        try {
            await deleteTheme(config, id);
            setThemes(prev => prev.filter(t => t.id !== id));
            if (selectedThemePrompt === themes.find(t => t.id === id)?.prompt) { onSelect(''); }
        } catch (e) { alert("Failed to delete."); }
    };

    return (
        <div className="space-y-2">
            <div className="flex justify-between items-end">
                <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Creative Direction</label>
                <button onClick={() => setShowModal(true)} className="text-[10px] text-primary-light hover:text-white underline">Manage Presets</button>
            </div>
            <div className="relative">
                <select value={selectedThemePrompt} onChange={(e) => onSelect(e.target.value)} className="w-full appearance-none bg-gray-900 border border-gray-600 rounded-lg px-3 py-2 text-sm text-white focus:ring-1 focus:ring-primary outline-none">
                    <option value="">Select a Direction...</option>
                    {themes.map(t => <option key={t.id} value={t.prompt}>{t.name}</option>)}
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-500"><svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg></div>
            </div>
            {showModal && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
                    <div className="bg-gray-800 rounded-xl border border-gray-700 w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
                        <div className="bg-gray-900/50 p-4 border-b border-gray-700 flex justify-between items-center">
                            <h3 className="text-md font-bold text-white">Manage Creative Directions</h3>
                            <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-white"><Icon name="close" className="w-5 h-5" /></button>
                        </div>
                        <div className="p-4 overflow-y-auto flex-1 space-y-6">
                            <div className="bg-gray-700/30 p-4 rounded-lg border border-gray-600 space-y-3">
                                <h4 className="text-xs font-bold text-primary-light uppercase">Add New Custom Preset</h4>
                                <input type="text" placeholder="Name" className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-sm text-white focus:border-primary outline-none" value={newName} onChange={e => setNewName(e.target.value)} />
                                <textarea placeholder="Prompt Instruction" className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-sm text-white h-24 resize-none focus:border-primary outline-none" value={newPrompt} onChange={e => setNewPrompt(e.target.value)} />
                                <button onClick={handleCreate} disabled={isSaving || !newName || !newPrompt} className="w-full bg-primary hover:bg-primary-hover disabled:bg-gray-600 text-white py-2 rounded text-sm font-bold transition-colors shadow-md">{isSaving ? 'Saving...' : 'Save to Airtable'}</button>
                            </div>
                            <div className="space-y-3">
                                <h4 className="text-xs font-bold text-gray-400 uppercase sticky top-0 bg-gray-800 py-1">Existing Presets</h4>
                                {themes.map(t => (
                                    <div key={t.id} className="flex items-start justify-between bg-gray-900/50 p-3 rounded border border-gray-700 hover:border-gray-500 transition-colors">
                                        <div className="flex-1 mr-3 overflow-hidden">
                                            <div className="flex items-center gap-2 mb-1">
                                                <span className="text-sm font-bold text-gray-200">{t.name}</span>
                                                {t.id.startsWith('def-') && <span className="text-[9px] bg-gray-700 text-gray-400 px-1.5 py-0.5 rounded uppercase tracking-wider">Default</span>}
                                            </div>
                                            <div className="text-xs text-gray-500 leading-tight line-clamp-2">{t.prompt}</div>
                                        </div>
                                        {!t.id.startsWith('def-') && (
                                            <button onClick={() => handleDelete(t.id)} className="text-red-400 hover:text-red-300 p-2 hover:bg-red-900/20 rounded transition-colors"><Icon name="close" className="w-4 h-4" /></button>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};
export default CreativeDirectionManager;`,

  'components/HistoryFeed.tsx': `
import React from 'react';
import { HistoryItem } from '../App';
import Icon from './Icon';

interface HistoryFeedProps {
    history: HistoryItem[];
    onSelect: (item: HistoryItem) => void;
}

const HistoryFeed: React.FC<HistoryFeedProps> = ({ history, onSelect }) => {
    return (
        <div className="bg-gray-800/50 rounded-2xl p-6 border border-gray-700">
            <h2 className="text-2xl font-semibold text-gray-200 mb-4">Your Creations</h2>
            <div className="flex overflow-x-auto space-x-4 pb-4">
                {history.map((item) => (
                    <div key={item.id} className="group relative flex-shrink-0 cursor-pointer" onClick={() => onSelect(item)}>
                        {item.imageUrl ? (
                             <div className="relative">
                                 <img src={item.imageUrl} alt={item.prompt} className={\`w-40 h-40 object-cover rounded-lg border transition-colors \${item.isLocalOnly ? 'border-orange-500/50' : 'border-gray-700 group-hover:border-primary'}\`} />
                                {item.isLocalOnly && (
                                    <div className="absolute top-2 right-2 bg-black/70 p-1 rounded-full text-orange-400" title="Saved to Local Hard Drive">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4"><path d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zm0 10.5a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10z" /></svg>
                                    </div>
                                )}
                             </div>
                        ) : (
                             <div className="w-40 h-40 rounded-lg bg-gray-700/50 border border-gray-600 flex flex-col items-center justify-center p-2 text-center group-hover:border-primary transition-colors">
                                <Icon name={item.type === 'video' ? 'video' : 'image'} className="w-8 h-8 text-gray-500 mb-2" />
                                <span className="text-[10px] text-gray-400 line-clamp-3 leading-tight px-1">{item.prompt}</span>
                             </div>
                        )}
                        {item.imageUrl && (
                            <div className="absolute inset-0 bg-black bg-opacity-60 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-lg">
                                 {item.type === 'video' && <Icon name="play" className="w-10 h-10 text-white mb-1" />}
                                <p className="text-white text-center text-sm p-2 font-bold">Open</p>
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};
export default HistoryFeed;`,

  'components/Icon.tsx': `
import React from 'react';

interface IconProps {
  name: 'image' | 'sparkles' | 'bulb' | 'video' | 'play' | 'settings' | 'close';
  className?: string;
}

const icons: { [key in IconProps['name']]: React.ReactElement } = {
  image: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
    </svg>
  ),
  sparkles: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456zM16.898 20.562L16.25 22.5l-.648-1.938a3.375 3.375 0 00-2.456-2.456L11.25 18l1.938-.648a3.375 3.375 0 002.456-2.456L16.25 13.5l.648 1.938a3.375 3.375 0 002.456 2.456L21 18l-1.938.648a3.375 3.375 0 00-2.456 2.456z" />
    </svg>
  ),
  bulb: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 18v-5.25m0 0a6.01 6.01 0 0 0 1.5-.189m-1.5.189a6.01 6.01 0 0 1-1.5-.189m3.75 7.478a12.06 12.06 0 0 1-4.5 0m3.75 2.311a15.045 15.045 0 0 1-4.5 0M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9 2.625c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125S9.875 11.379 9.875 12v1.5c0 .621.504 1.125 1.125 1.125Z" />
    </svg>
  ),
  video: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" d="m15.75 10.5 4.72-4.72a.75.75 0 0 1 1.28.53v11.38a.75.75 0 0 1-1.28.53l-4.72-4.72M4.5 18.75h9a2.25 2.25 0 0 0 2.25-2.25v-9a2.25 2.25 0 0 0-2.25-2.25h-9A2.25 2.25 0 0 0 2.25 7.5v9A2.25 2.25 0 0 0 4.5 18.75Z" />
    </svg>
  ),
  play: (
     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
      <path fillRule="evenodd" d="M4.5 5.653c0-1.426 1.529-2.33 2.779-1.643l11.54 6.648c1.295.742 1.295 2.545 0 3.286L7.279 20.99c-1.25.717-2.779-.217-2.779-1.643V5.653Z" clipRule="evenodd" />
    </svg>
  ),
  settings: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.324.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 0 1 1.37.49l1.296 2.247a1.125 1.125 0 0 1-.26 1.431l-1.003.827c-.293.24-.438.613-.431.992a6.759 6.759 0 0 1 0 .255c-.007.378.138.75.43.99l1.005.828c.424.35.534.954.26 1.43l-1.298 2.247a1.125 1.125 0 0 1-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.57 6.57 0 0 1-.22.128c-.331.183-.581.495-.644.869l-.213 1.28c-.09.543-.56.941-1.11.941h-2.594c-.55 0-1.02-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 0 1-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 0 1-1.369-.49l-1.297-2.247a1.125 1.125 0 0 1 .26-1.431l1.004-.827c.292-.24.437-.613.43-.992a6.932 6.932 0 0 1 0-.255c.007-.378-.138-.75-.43-.99l-1.004-.828a1.125 1.125 0 0 1-.26-1.43l1.297-2.247a1.125 1.125 0 0 1 1.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.087.22-.128.332-.183.582-.495.644-.869l.214-1.281Z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
    </svg>
  ),
  close: (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" d="M6 18 18 6M6 6l12 12" />
    </svg>
  )
};

const Icon: React.FC<IconProps> = ({ name, className = 'h-6 w-6' }) => {
  return <div className={className}>{icons[name]}</div>;
};

export default Icon;`,

  'components/ImageDropzone.tsx': `
import React, { useState, useRef, ChangeEvent, DragEvent } from 'react';
import ImagePlaceholder from './ImagePlaceholder';

interface ImageState {
  file: File | null;
  dataUrl: string | null;
}

interface ImageDropzoneProps {
  imageState: ImageState;
  onFileSelect: (file: File) => void;
  onRemove: () => void;
  placeholderLabel: string;
}

const StaticImagePlaceholder = ({ label }: { label: string }) => (
    <div className="flex flex-col items-center justify-center w-full h-full bg-gray-900/30 border-2 border-dashed border-gray-600 rounded-lg p-8 text-center">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="h-16 w-16 text-gray-500 mb-4">
        <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
      </svg>
      <span className="text-gray-400">{label}</span>
    </div>
);

const ImageDropzone: React.FC<ImageDropzoneProps> & { Placeholder: typeof StaticImagePlaceholder } = ({
  imageState,
  onFileSelect,
  onRemove,
  placeholderLabel,
}) => {
  const [isDraggingOver, setIsDraggingOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragEnter = (e: DragEvent<HTMLDivElement>) => { e.preventDefault(); e.stopPropagation(); setIsDraggingOver(true); };
  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => { e.preventDefault(); e.stopPropagation(); setIsDraggingOver(false); };
  const handleDragOver = (e: DragEvent<HTMLDivElement>) => { e.preventDefault(); e.stopPropagation(); };
  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault(); e.stopPropagation(); setIsDraggingOver(false);
    const files = e.dataTransfer.files;
    if (files && files[0] && files[0].type.startsWith('image/')) { onFileSelect(files[0]); }
  };
  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => { if (e.target.files && e.target.files[0]) { onFileSelect(e.target.files[0]); } };
  const triggerFileSelect = () => { fileInputRef.current?.click(); };

  return (
    <div className="w-full h-full min-h-[200px] flex items-center justify-center">
      <input type="file" accept="image/*" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
      {imageState.dataUrl ? (
        <div className="relative group w-full">
          <img src={imageState.dataUrl} alt="Uploaded content" className="w-full h-auto max-h-[300px] object-contain rounded-lg" />
          <div className="absolute top-2 right-2 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <button onClick={triggerFileSelect} className="bg-gray-900/70 text-white px-3 py-1 rounded-md text-sm hover:bg-gray-800/90">Change</button>
            <button onClick={onRemove} className="bg-red-600/80 text-white p-1 rounded-full hover:bg-red-500/90" aria-label="Remove image">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>
        </div>
      ) : (
        <div className="w-full h-full" onDragEnter={handleDragEnter} onDragLeave={handleDragLeave} onDragOver={handleDragOver} onDrop={handleDrop} onClick={triggerFileSelect}>
          <ImagePlaceholder label={placeholderLabel} isDraggingOver={isDraggingOver} />
        </div>
      )}
    </div>
  );
};
ImageDropzone.Placeholder = StaticImagePlaceholder;
export default ImageDropzone;`,

  'components/ImagePlaceholder.tsx': `
import React from 'react';
import Icon from './Icon';

interface ImagePlaceholderProps {
  label: string;
  isDraggingOver?: boolean;
}

const ImagePlaceholder: React.FC<ImagePlaceholderProps> = ({ label, isDraggingOver }) => {
  const baseClasses = "flex flex-col items-center justify-center w-full h-full bg-gray-900/30 border-2 border-dashed rounded-lg p-8 text-center transition-colors duration-300";
  const stateClasses = isDraggingOver ? "border-primary cursor-copy" : "border-gray-600 hover:border-gray-500 cursor-pointer";
  return (
    <div className={\`\${baseClasses} \${stateClasses}\`}>
      <Icon name="image" className="h-16 w-16 text-gray-500 mb-4" />
      <span className="text-gray-400">{label}</span>
    </div>
  );
};
export default ImagePlaceholder;`,

  'components/Spinner.tsx': `
import React from 'react';
const Spinner: React.FC = () => (
  <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
  </svg>
);
export default Spinner;`,

  'components/Suggestions.tsx': `
import React from 'react';
import Spinner from './Spinner';

interface SuggestionsProps {
    suggestions: string[];
    onApply: (suggestion: string) => void;
    isLoading: boolean;
}

const Suggestions: React.FC<SuggestionsProps> = ({ suggestions, onApply, isLoading }) => {
    if (isLoading) return <div className="flex items-center justify-center w-full mt-2"><Spinner /></div>;
    if (suggestions.length === 0) return null;
    return (
        <div className="w-full mt-2 p-4 bg-gray-900/50 rounded-lg border border-gray-700">
            <h3 className="text-md font-semibold text-gray-300 mb-2">Try these ideas:</h3>
            <div className="flex flex-col space-y-2">
                {suggestions.map((suggestion, index) => (
                    <button key={index} onClick={() => onApply(suggestion)} className="w-full text-left p-2 bg-gray-700 hover:bg-gray-600 rounded-md text-sm text-gray-200 transition-colors">"{suggestion}"</button>
                ))}
            </div>
        </div>
    );
};
export default Suggestions;`,

  'components/SettingsModal.tsx': `
import React, { useState, useEffect } from 'react';
import Icon from './Icon';
import { AirtableConfig, checkAirtableConnection } from '../services/airtableService';
import Spinner from './Spinner';
import { HistoryItem } from '../App';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: AirtableConfig;
  onSave: (config: AirtableConfig) => void;
  history: HistoryItem[];
}

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, config, onSave, history }) => {
  const [activeTab, setActiveTab] = useState<'database' | 'developer'>('database');
  const [apiKey, setApiKey] = useState(config.apiKey);
  const [baseId, setBaseId] = useState(config.baseId);
  const [tableName, setTableName] = useState(config.tableName || 'Generations');
  const [imgbbApiKey, setImgbbApiKey] = useState(config.imgbbApiKey || '');
  const [testStatus, setTestStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');
  const [testMessage, setTestMessage] = useState('');

  useEffect(() => {
    if (isOpen) {
      setApiKey(config.apiKey); setBaseId(config.baseId); setTableName(config.tableName || 'Generations'); setImgbbApiKey(config.imgbbApiKey || '');
      setTestStatus('idle'); setTestMessage('');
    }
  }, [isOpen, config]);

  const handleSave = () => { onSave({ apiKey, baseId, tableName, imgbbApiKey }); onClose(); };
  
  const handleTestConnection = async () => {
      setTestStatus('testing'); setTestMessage('');
      try { await checkAirtableConnection({ apiKey, baseId, tableName }); setTestStatus('success'); setTestMessage('Airtable Connection successful!'); } catch (e: any) { setTestStatus('error'); setTestMessage(e.message || "Failed to connect"); }
  };

  const downloadSetupScript = () => {
    const scriptContent = \`#!/bin/bash
echo "---------------------------------------"
echo "  Gemini Studio - GitHub Auto-Setup"
echo "---------------------------------------"
echo "1. Initializing Git..."
git init
echo "2. Adding files..."
git add .
echo "3. Committing..."
git commit -m "Initial commit from Gemini Presentation Studio"
echo "---------------------------------------"
echo "Paste your GitHub Repository URL (e.g., https://github.com/user/repo.git):"
read repo_url
if [ -z "$repo_url" ]; then echo "Error: No URL provided."; exit 1; fi
echo "4. Linking Remote..."
git remote add origin $repo_url
echo "5. Pushing Code..."
git branch -M main
git push -u origin main
echo "---------------------------------------"
echo "Done! Check your GitHub repository."
read -p "Press enter to exit"
\`;
    const blob = new Blob([scriptContent], { type: 'text/x-sh' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'setup_github.sh'; document.body.appendChild(a); a.click(); document.body.removeChild(a);
  };

  const downloadBackup = () => {
      const data = { config: { apiKey, baseId, tableName, imgbbApiKey }, timestamp: new Date().toISOString(), history: history };
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url; a.download = \`gemini_studio_backup_\${new Date().toISOString().slice(0,10)}.json\`; document.body.appendChild(a); a.click(); document.body.removeChild(a);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
      <div className="bg-gray-800 rounded-xl border border-gray-700 w-full max-w-md shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        <div className="bg-gray-900/50 p-4 border-b border-gray-700 flex justify-between items-center sticky top-0 backdrop-blur-md">
          <h3 className="text-lg font-bold text-white flex items-center gap-2"><Icon name="settings" className="w-5 h-5 text-gray-400" /> Settings</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors"><Icon name="close" className="w-5 h-5" /></button>
        </div>
        <div className="flex border-b border-gray-700 bg-gray-900/30">
            <button onClick={() => setActiveTab('database')} className={\`flex-1 py-3 text-sm font-medium transition-colors \${activeTab === 'database' ? 'text-primary border-b-2 border-primary bg-primary/5' : 'text-gray-400 hover:text-white'}\`}>Database</button>
            <button onClick={() => setActiveTab('developer')} className={\`flex-1 py-3 text-sm font-medium transition-colors \${activeTab === 'developer' ? 'text-primary border-b-2 border-primary bg-primary/5' : 'text-gray-400 hover:text-white'}\`}>Developer & Git</button>
        </div>
        <div className="p-6 space-y-6 overflow-y-auto">
          {activeTab === 'database' && (
              <>
                <div className="space-y-4">
                    <h4 className="text-sm font-bold text-primary-light uppercase tracking-wide border-b border-gray-700 pb-1">Airtable Config</h4>
                    <p className="text-xs text-gray-400">You need a Personal Access Token (PAT) with <code>data.records:write</code> scope.</p>
                    <div><label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Personal Access Token (PAT)</label><input type="password" value={apiKey} onChange={(e) => setApiKey(e.target.value)} placeholder="pat.xxxxxxxx..." className="w-full bg-gray-900 border border-gray-600 rounded-lg px-3 py-2 text-sm text-white focus:ring-1 focus:ring-primary outline-none" /></div>
                    <div className="grid grid-cols-2 gap-3">
                        <div><label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Base ID</label><input type="text" value={baseId} onChange={(e) => setBaseId(e.target.value)} placeholder="app..." className="w-full bg-gray-900 border border-gray-600 rounded-lg px-3 py-2 text-sm text-white focus:ring-1 focus:ring-primary outline-none" /></div>
                        <div><label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Table Name</label><input type="text" value={tableName} onChange={(e) => setTableName(e.target.value)} placeholder="Generations" className="w-full bg-gray-900 border border-gray-600 rounded-lg px-3 py-2 text-sm text-white focus:ring-1 focus:ring-primary outline-none" /></div>
                    </div>
                </div>
                <div className="space-y-4 pt-4 border-t border-gray-700">
                    <h4 className="text-sm font-bold text-primary-light uppercase tracking-wide border-b border-gray-700 pb-1">Image Upload Bridge</h4>
                    <p className="text-xs text-gray-400">Required to auto-save images to Airtable. <a href="https://api.imgbb.com/" target="_blank" className="text-primary hover:underline">Get free Key</a></p>
                    <div><label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">ImgBB API Key</label><input type="password" value={imgbbApiKey} onChange={(e) => setImgbbApiKey(e.target.value)} placeholder="32-character key..." className="w-full bg-gray-900 border border-gray-600 rounded-lg px-3 py-2 text-sm text-white focus:ring-1 focus:ring-primary outline-none" /></div>
                </div>
                <div className="pt-4 border-t border-gray-700 flex items-center justify-between">
                     <div className="text-xs">{testStatus === 'testing' && <span className="text-yellow-400 flex items-center gap-1"><Spinner/> Connecting...</span>}{testStatus === 'success' && <span className="text-green-400">{testMessage}</span>}{testStatus === 'error' && <span className="text-red-400">{testMessage}</span>}</div>
                     <button onClick={handleTestConnection} disabled={testStatus === 'testing' || !apiKey || !baseId} className="text-xs bg-gray-700 hover:bg-gray-600 px-3 py-2 rounded text-white font-medium">Test Connection</button>
                </div>
              </>
          )}
          {activeTab === 'developer' && (
              <div className="space-y-6">
                  <div className="bg-gray-700/30 p-4 rounded-lg border border-gray-600">
                      <h4 className="text-sm font-bold text-white mb-2">GitHub Auto-Setup</h4>
                      <p className="text-xs text-gray-400 mb-4">Download a script to automatically initialize Git and push this project to your GitHub repository.</p>
                      <button onClick={downloadSetupScript} className="w-full bg-gray-800 hover:bg-gray-700 border border-gray-600 text-white py-2 rounded-lg text-sm font-bold flex items-center justify-center gap-2">Download Script (.sh)</button>
                  </div>
                  <div className="bg-gray-700/30 p-4 rounded-lg border border-gray-600">
                      <h4 className="text-sm font-bold text-white mb-2">Local Backup</h4>
                      <p className="text-xs text-gray-400 mb-4">Download a JSON file containing your configuration and generation history.</p>
                      <button onClick={downloadBackup} className="w-full bg-gray-800 hover:bg-gray-700 border border-gray-600 text-white py-2 rounded-lg text-sm font-bold flex items-center justify-center gap-2"><Icon name="sparkles" className="w-4 h-4"/> Download Backup JSON</button>
                  </div>
              </div>
          )}
        </div>
        <div className="p-4 border-t border-gray-700 bg-gray-900/50 flex justify-end gap-3 sticky bottom-0">
          <button onClick={onClose} className="px-4 py-2 text-sm text-gray-400 hover:text-white transition-colors">Cancel</button>
          <button onClick={handleSave} className="bg-primary hover:bg-primary-hover text-white px-6 py-2 rounded-lg font-bold shadow-lg transition-transform transform hover:scale-105">Save Changes</button>
        </div>
      </div>
    </div>
  );
};
export default SettingsModal;`,

  'data/templates.ts': `
export interface PromptTemplate {
  id: string;
  title: string;
  description: string;
  prompt: string;
  category?: string;
}

export interface TemplateCategory {
  id: string;
  label: string;
  templates: PromptTemplate[];
}

export const TEMPLATE_CATEGORIES: TemplateCategory[] = [
  {
    id: 'illustration',
    label: 'Illustration & Character',
    templates: [
      { id: 'character-turnaround', title: 'Character Turnaround', description: '4-view character sheet with expressions.', prompt: "Create a complete four-view turnaround sheet for a high-detail fictional role: [content]. Show frontal, right side, left side, and back views, plus three distinct emotional expressions. Use a clean vector illustration style, maintaining consistent character identity and color palette across all panels." },
      { id: 'manga-panel', title: 'Manga / Graphic Novel', description: 'Dynamic action scene with high contrast.', prompt: "Generate a Manga panel depicting [content] in a [topic]. Use a dynamic low-angle shot with dramatic, high-contrast shadows." }
    ]
  },
  {
    id: 'infographic',
    label: 'Infographics & Diagrams',
    templates: [
      { id: 'info-process', title: 'Informational Infographic', description: 'Detailed process with legible text.', prompt: "Generate an educational infographic about [topic] outlining a detailed, multi-step process: [content]. Use labeled boxes, clear arrows connecting steps, and concise definitions. Ensure the text is perfectly legible in crisp sans-serif typography. Use a clean vector art style with a three-color brand palette." },
      { id: 'flowchart', title: 'Flowchart / Process Map', description: 'Vertical flow with hand-drawn style.', prompt: "Transform a sequential decision pathway into a vertical flowchart about [topic]: [content]. Ensure arrows clearly connect each labeled box or decision point. Use a whiteboard illustration style with a readable, hand-drawn marker font." },
      { id: 'isometric-schematic', title: 'Isometric Schematic', description: 'Technical diagram with 3D depth.', prompt: "Generate an isometric schematic diagram of [content]. Include clearly labeled components and devices. Use clean technical line art on a white background. Ensure accurate angles and depth for the 3D-looking design." },
      { id: 'dashboard', title: 'Dashboard Graphic', description: 'Business metrics with charts.', prompt: "Create a clean dashboard graphic summarizing [content] using a clear hierarchy of bar charts, pie graphs, and KPI display blocks. Integrate a small, legible title text: '[topic]'. Use a modern UI design aesthetic." }
    ]
  },
  {
    id: 'photo',
    label: 'Realism & Products',
    templates: [
      { id: 'exec-headshot', title: 'Executive Headshot', description: 'Professional portrait, modern office.', prompt: "Create an executive-level professional headshot of [content] in tailored business attire with a natural, confident expression. Set the scene in a modern corporate office with soft natural window lighting, creating a high-resolution professional finish." },
      { id: 'product-render', title: 'Luxury Product Render', description: 'High-end materials and lighting.', prompt: "Produce a luxury product rendering of [content] for [topic]. Use a brushed aluminum cap and embossed surface texture. Use soft side reflections and studio lighting, ensuring realistic light physics and material awareness." }
    ]
  },
  {
    id: 'ads',
    label: 'Advertising & Social',
    templates: [
      { id: 'social-ad', title: 'Social Media Ad', description: 'High impact creative with headline.', prompt: "Design a high-impact social media ad creative. Feature [content] in a bright, appealing lifestyle setting. The bold, white headline '[topic]' must be rendered flawlessly at the top. Use commercial photography standard." },
      { id: 'product-mockup', title: 'Apparel/Product Mockup', description: 'Realistic mockup with alignment.', prompt: "Minimal [content] mockup made of soft fabric with realistic fold shadows. Place a placeholder logo printed in deep black ink with precise alignment. Use studio lighting and a front view." }
    ]
  },
  {
    id: 'video',
    label: 'Video Prep & Cinematic',
    templates: [
      { id: 'storyboard', title: 'Storyboard Sequence', description: '3-panel cinematic sequence.', prompt: "Create a cinematic storyboard sequence showing [content]. Use three separate frames with varying dynamic camera angles (low-angle, close-up, wide shot). Maintain exact character consistency across all panels." },
      { id: 'scene-foundation', title: 'Cinematic Scene Foundation', description: 'Photorealistic film establishing shot.', prompt: "Generate a photorealistic film scene foundation of [content]. Use a wide shot with Golden hour backlighting creating volumetric atmospheric effects. Apply cinematic color grading with muted tones." }
    ]
  }
];`,

  'data/themes.ts': `
export interface ThemeDeck {
    id: string;
    label: string;
    description: string;
    color: string;
    modifiers: string;
}

export const THEME_DECKS: ThemeDeck[] = [
    {
        id: 'corporate-blue',
        label: 'Corporate Blue',
        description: 'Trustworthy, clean, navy & white palette, vector style.',
        color: 'from-blue-600 to-blue-800',
        modifiers: "in a professional Corporate Memphis style. Use a strict color palette of Navy Blue (#003366), Clean White, and soft grey accents. Flat vector illustration, minimalist composition, sans-serif typography compatibility."
    }
];`,

  'components/TemplateLibraryModal.tsx': `
import React, { useState, useEffect } from 'react';
import Icon from './Icon';
import { PromptTemplate, TEMPLATE_CATEGORIES as DEFAULT_CATEGORIES } from '../data/templates';
import { AirtableConfig, fetchTemplates, createTemplate } from '../services/airtableService';
import Spinner from './Spinner';

interface TemplateLibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTemplate: (template: PromptTemplate) => void;
  config: AirtableConfig;
}

const TemplateLibraryModal: React.FC<TemplateLibraryModalProps> = ({ isOpen, onClose, onSelectTemplate, config }) => {
  const [activeCategory, setActiveCategory] = useState('illustration');
  const [customTemplates, setCustomTemplates] = useState<PromptTemplate[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newPrompt, setNewPrompt] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => { if (isOpen) loadTemplates(); }, [isOpen, config]);

  const loadTemplates = async () => {
      setIsLoading(true);
      try {
          const records = await fetchTemplates(config);
          const mapped: PromptTemplate[] = records.map(r => ({ id: r.id, title: r.title, description: r.description, prompt: r.prompt, category: r.category || 'Custom' }));
          setCustomTemplates(mapped);
      } catch (e) {
          console.error("Failed to load templates", e);
      } finally {
          setIsLoading(false);
      }
  };

  const handleAddTemplate = async () => {
      if (!newTitle || !newPrompt) return;
      setIsSaving(true);
      try {
          const newRec = await createTemplate(config, newTitle, newDesc, newPrompt, activeCategory);
          const newTmpl: PromptTemplate = { id: newRec.id, title: newRec.title, description: newRec.description, prompt: newRec.prompt, category: 'Custom' };
          setCustomTemplates(prev => [...prev, newTmpl]);
          setShowAddForm(false);
          setNewTitle(''); setNewDesc(''); setNewPrompt('');
      } catch (e) {
          alert("Failed to save template. Ensure 'Templates' table exists in Airtable.");
      } finally {
          setIsSaving(false);
      }
  };

  if (!isOpen) return null;
  const categories = [...DEFAULT_CATEGORIES];
  const currentCategoryData = categories.find(c => c.id === activeCategory);
  const displayTemplates = activeCategory === 'custom' ? customTemplates : (currentCategoryData?.templates || []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-gray-800 rounded-xl border border-gray-700 w-full max-w-5xl h-[85vh] shadow-2xl overflow-hidden flex flex-col">
        <div className="bg-gray-900/50 p-4 border-b border-gray-700 flex justify-between items-center shrink-0">
          <div><h3 className="text-xl font-bold text-white flex items-center gap-2"><Icon name="bulb" className="w-6 h-6 text-primary" /> Active Prompt Structures</h3><p className="text-sm text-gray-400 mt-1">Select or create a professional structure.</p></div>
          <button onClick={onClose} className="text-gray-400 hover:text-white"><Icon name="close" className="w-6 h-6" /></button>
        </div>
        <div className="flex flex-1 overflow-hidden">
          <div className="w-64 bg-gray-900/30 border-r border-gray-700 overflow-y-auto p-4 space-y-2">
            {categories.map((cat) => (
              <button key={cat.id} onClick={() => { setActiveCategory(cat.id); setShowAddForm(false); }} className={\`w-full text-left px-4 py-3 rounded-lg text-sm font-medium transition-all \${activeCategory === cat.id ? 'bg-primary/20 text-white border border-primary/50' : 'text-gray-400 hover:bg-gray-800'}\`}>{cat.label}</button>
            ))}
            <div className="border-t border-gray-700 my-2 pt-2"></div>
            <button onClick={() => { setActiveCategory('custom'); setShowAddForm(false); }} className={\`w-full text-left px-4 py-3 rounded-lg text-sm font-medium transition-all \${activeCategory === 'custom' ? 'bg-primary/20 text-white border border-primary/50' : 'text-gray-400 hover:bg-gray-800'}\`}>My Custom Templates</button>
          </div>
          <div className="flex-1 overflow-y-auto p-6 bg-gray-800 relative">
             <div className="flex justify-between items-center mb-6 border-b border-gray-700 pb-2">
                <h4 className="text-lg font-bold text-white">{activeCategory === 'custom' ? 'Custom Library' : currentCategoryData?.label}</h4>
                {activeCategory === 'custom' && (<button onClick={() => setShowAddForm(true)} className="bg-green-600 hover:bg-green-500 text-white text-xs px-3 py-1.5 rounded font-bold shadow">+ Create New</button>)}
             </div>
             {showAddForm && (
                 <div className="bg-gray-700/50 p-4 rounded-xl border border-gray-600 mb-6 animate-fadeIn">
                     <div className="flex justify-between mb-2"><h5 className="font-bold text-white text-sm">New Template</h5><button onClick={() => setShowAddForm(false)} className="text-gray-400 hover:text-white"><Icon name="close" className="w-4 h-4"/></button></div>
                     <div className="space-y-3">
                         <input className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-sm text-white focus:border-primary outline-none" placeholder="Title" value={newTitle} onChange={e => setNewTitle(e.target.value)} />
                         <input className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-sm text-white focus:border-primary outline-none" placeholder="Description" value={newDesc} onChange={e => setNewDesc(e.target.value)} />
                         <textarea className="w-full h-24 bg-gray-900 border border-gray-600 rounded px-3 py-2 text-sm text-white focus:border-primary outline-none resize-none" placeholder="Prompt [content] [topic]" value={newPrompt} onChange={e => setNewPrompt(e.target.value)} />
                         <button onClick={handleAddTemplate} disabled={isSaving} className="bg-primary hover:bg-primary-hover text-white px-4 py-2 rounded text-sm font-bold">{isSaving ? 'Saving...' : 'Save Template'}</button>
                     </div>
                 </div>
             )}
             {isLoading ? <div className="p-10 text-center"><Spinner /></div> : (
                 <div className="grid grid-cols-1 gap-4">
                   {displayTemplates.length === 0 && <div className="text-gray-500 italic">No templates found in this category.</div>}
                   {displayTemplates.map((template) => (
                     <div key={template.id} className="group bg-gray-700/30 hover:bg-gray-700/60 border border-gray-600 hover:border-primary/50 rounded-xl p-5 transition-all duration-200">
                       <div className="flex justify-between items-start mb-2">
                         <h5 className="text-md font-bold text-gray-200 group-hover:text-primary-light transition-colors">{template.title}</h5>
                         <button onClick={() => { onSelectTemplate(template); onClose(); }} className="bg-gray-800 hover:bg-primary text-gray-300 hover:text-white text-xs px-3 py-1 rounded-full border border-gray-600 transition-colors">Use Template</button>
                       </div>
                       <p className="text-xs text-gray-400 mb-3 italic">{template.description}</p>
                       <div className="bg-gray-900/50 p-3 rounded-lg border border-gray-700/50 font-mono text-xs text-gray-300 leading-relaxed line-clamp-3">{template.prompt}</div>
                     </div>
                   ))}
                 </div>
             )}
          </div>
        </div>
      </div>
    </div>
  );
};
export default TemplateLibraryModal;`,

  'components/ThemeSelector.tsx': `
import React from 'react';
import { ThemeDeck, THEME_DECKS } from '../data/themes';

interface ThemeSelectorProps {
    selectedThemeId: string;
    onSelect: (themeId: string) => void;
}

const ThemeSelector: React.FC<ThemeSelectorProps> = ({ selectedThemeId, onSelect }) => {
    return (
        <div className="space-y-3">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Creative Direction / Theme</label>
            <div className="grid grid-cols-2 gap-3">
                {THEME_DECKS.map((theme) => {
                    const isSelected = selectedThemeId === theme.id;
                    return (
                        <button key={theme.id} onClick={() => onSelect(theme.id)} className={\`relative overflow-hidden rounded-xl p-3 text-left transition-all duration-200 border \${isSelected ? 'border-white ring-2 ring-primary ring-offset-2 ring-offset-gray-900 scale-[1.02]' : 'border-gray-700 hover:border-gray-500 hover:bg-gray-800'}\`}>
                            <div className={\`absolute top-0 right-0 w-16 h-16 bg-gradient-to-br \${theme.color} opacity-20 blur-xl rounded-full -mr-4 -mt-4\`}></div>
                            <div className="relative z-10">
                                <div className="flex items-center justify-between mb-1">
                                    <span className={\`font-bold text-sm \${isSelected ? 'text-white' : 'text-gray-300'}\`}>{theme.label}</span>
                                    {isSelected && <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>}
                                </div>
                                <p className="text-[10px] text-gray-500 leading-tight">{theme.description}</p>
                            </div>
                        </button>
                    );
                })}
            </div>
        </div>
    );
};
export default ThemeSelector;`,

  'components/VideoPlayer.tsx': `
import React from 'react';
interface VideoPlayerProps { src: string; }
const VideoPlayer: React.FC<VideoPlayerProps> = ({ src }) => {
  return (
    <div className="w-full">
      <video key={src} controls autoPlay muted loop className="w-full h-auto max-h-[450px] object-contain rounded-lg">
        <source src={src} type="video/mp4" />
        Your browser does not support the video tag.
      </video>
    </div>
  );
};
export default VideoPlayer;`,

  'App.tsx': `
import React, { useState, ChangeEvent, useEffect, useCallback, useRef } from 'react';
import { editImageWithPrompt, generateImageFromPrompt, getSuggestionsForImage, generateVideoFromPrompt } from './services/geminiService';
import { saveRecordToAirtable, fetchGenerationHistory, AirtableConfig, fetchControls, ControlRecord } from './services/airtableService';
import { saveLocalImage, getLocalImage } from './services/dbService';
import Spinner from './components/Spinner';
import Icon from './components/Icon';
import VideoPlayer from './components/VideoPlayer';
import ImageDropzone from './components/ImageDropzone';
import ControlSelect from './components/ControlSelect';
import SettingsModal from './components/SettingsModal';
import TemplateLibraryModal from './components/TemplateLibraryModal';
import ControlManagerModal from './components/ControlManagerModal';
import Suggestions from './components/Suggestions';
import HistoryFeed from './components/HistoryFeed';
import CreativeDirectionManager from './components/CreativeDirectionManager';
import { PromptTemplate, TEMPLATE_CATEGORIES } from './data/templates';

interface ImageState {
  file: File | null;
  dataUrl: string | null;
}

export type HistoryItem = {
  id: string;
  type: 'image' | 'video';
  topic: string;
  campaign: string;
  isFavorite: boolean;
  imageUrl: string | null; 
  videoUrl?: string | null;
  prompt: string;
  aspectRatio?: string;
  resolution?: string;
  isLocalOnly?: boolean; 
  metadata?: {
    style?: string;
    layout?: string;
    lighting?: string;
    camera?: string;
    rawInput?: string;
    creativeDirection?: string;
    templateId?: string;
  }
}

type View = 'image' | 'video';
type ImageMode = 'edit' | 'generate';

const DEFAULT_LAYOUTS = [
  { value: '', label: 'Freeform (Default)' },
  { value: 'Professional Infographic', label: 'Infographic' },
  { value: 'Data Visualization Diagram', label: 'Chart / Dashboard' },
  { value: 'Standard Slide Layout', label: 'Slide' },
];

const App: React.FC = () => {
  const [view, setView] = useState<View>('image');
  const [imageMode, setImageMode] = useState<ImageMode>('generate');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [isApiKeySelected, setIsApiKeySelected] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('');
  const [isHistoryLoading, setIsHistoryLoading] = useState(false);
  const [topic, setTopic] = useState<string>('');
  const [campaign, setCampaign] = useState<string>('');
  const [visualStyle, setVisualStyle] = useState<string>('');
  const [lighting, setLighting] = useState<string>('');
  const [camera, setCamera] = useState<string>('');
  const [creativeDirectionPrompt, setCreativeDirectionPrompt] = useState<string>(''); 
  const [layouts, setLayouts] = useState(DEFAULT_LAYOUTS);
  const [styles, setStyles] = useState([{ value: '', label: 'None' }]);
  const [lightingOpts, setLightingOpts] = useState([{ value: '', label: 'Default' }]);
  const [cameraOpts, setCameraOpts] = useState([{ value: '', label: 'Default' }]);
  const [carouselIndex, setCarouselIndex] = useState<number>(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterTopic, setFilterTopic] = useState('');
  const [filterCampaign, setFilterCampaign] = useState('');
  const [originalImage, setOriginalImage] = useState<ImageState>({ file: null, dataUrl: null });
  const [userInput, setUserInput] = useState<string>(''); 
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [isSuggesting, setIsSuggesting] = useState<boolean>(false);
  const [imageAspectRatio, setImageAspectRatio] = useState<'1:1' | '3:4' | '4:3' | '9:16' | '16:9'>('16:9');
  const [imageResolution, setImageResolution] = useState<'1K' | '2K' | '4K'>('2K');
  const [layoutStyle, setLayoutStyle] = useState<string>('');
  const [videoPrompt, setVideoPrompt] = useState('');
  const [startImage, setStartImage] = useState<ImageState>({ file: null, dataUrl: null });
  const [videoAspectRatio, setVideoAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [videoResolution, setVideoResolution] = useState<'720p' | '1080p'>('720p');
  const [isManualMode, setIsManualMode] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<PromptTemplate | null>(null);
  const [isSavingToAirtable, setIsSavingToAirtable] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [airtableConfig, setAirtableConfig] = useState<AirtableConfig>({
    apiKey: 'pat0pZ8tbMCEsk7yp.62d9c13d06d4e91dfd969a29ae6dfb7d5c0409cbf6502b9a8740daf6f3bac686',
    baseId: 'appQlr4QtRarkte6L',
    tableName: 'Generations',
    imgbbApiKey: 'ad81196b9594f688d77d1466bbd5c935'
  });
  const [showTemplateLibrary, setShowTemplateLibrary] = useState(false);
  const [showControlManager, setShowControlManager] = useState(false);

  const getConstructedPrompt = useCallback(() => {
    if (view === 'video') return videoPrompt; 
    if (isManualMode || imageMode === 'edit') return userInput;
    let basePrompt = '';
    if (selectedTemplate) {
        basePrompt = selectedTemplate.prompt;
        const topicText = topic.trim() || 'the subject';
        const contentText = userInput.trim() || 'placeholder content';
        basePrompt = basePrompt.replace(/\\[topic\\]/gi, topicText);
        basePrompt = basePrompt.replace(/\\[subject\\]/gi, contentText);
        basePrompt = basePrompt.replace(/\\[content\\]/gi, contentText);
    } else {
        const safeTopic = topic.trim() ? \`about \${topic.trim()}\` : '';
        const safeLayout = layoutStyle ? \`[Layout: \${layoutStyle}]\` : '';
        basePrompt = \`\${safeLayout} \${safeTopic}: \${userInput.trim()}\`.trim();
    }
    if (creativeDirectionPrompt) {
        if (!basePrompt.endsWith('.')) basePrompt += '.';
        basePrompt += \` \${creativeDirectionPrompt}\`;
    }
    const aesthetics: string[] = [];
    if (visualStyle) aesthetics.push(\`Style: \${visualStyle}\`);
    if (lighting) aesthetics.push(\`Lighting: \${lighting}\`);
    if (camera) aesthetics.push(\`Camera: \${camera}\`);
    if (aesthetics.length > 0) {
        if (!basePrompt.endsWith('.')) basePrompt += '.';
        basePrompt += \` \${aesthetics.join('. ')}.\`;
    }
    return basePrompt;
  }, [view, isManualMode, imageMode, userInput, layoutStyle, topic, visualStyle, lighting, camera, videoPrompt, selectedTemplate, creativeDirectionPrompt]);

  const finalPrompt = getConstructedPrompt();

  useEffect(() => {
    const savedConfig = localStorage.getItem('airtableConfig');
    if (savedConfig) { setAirtableConfig(JSON.parse(savedConfig)); }
  }, []);

  const handleSaveSettings = (newConfig: AirtableConfig) => {
    setAirtableConfig(newConfig);
    localStorage.setItem('airtableConfig', JSON.stringify(newConfig));
    loadHistory(newConfig);
    loadDynamicControls(newConfig);
  };

  useEffect(() => { checkApiKey(); loadHistory(airtableConfig); loadDynamicControls(airtableConfig); }, []);

  const loadDynamicControls = async (config: AirtableConfig) => {
      try {
          const controls = await fetchControls(config);
          if (controls.length > 0) {
              const mapOptions = (cat: string, def: any[]) => {
                  const items = controls.filter(c => c.category === cat).map(c => ({ value: c.value, label: c.label }));
                  return items.length > 0 ? [{value:'', label:'Default'}, ...items] : def;
              };
              setLayouts(mapOptions('Layout', DEFAULT_LAYOUTS));
              setStyles(mapOptions('Style', [{value:'', label:'None'}]));
              setLightingOpts(mapOptions('Lighting', [{value:'', label:'Default'}]));
              setCameraOpts(mapOptions('Camera', [{value:'', label:'Default'}]));
          }
      } catch (e) { console.warn("Failed to load controls from Airtable, using defaults."); }
  };
  
  const loadHistory = async (config: AirtableConfig) => {
      setIsHistoryLoading(true);
      try {
          const remoteHistory = await fetchGenerationHistory(config);
          const mergedHistory = await Promise.all(remoteHistory.map(async (item: HistoryItem) => {
              if (!item.imageUrl && !item.videoUrl) {
                  const localImage = await getLocalImage(item.id);
                  if (localImage) {
                      return { 
                          ...item, 
                          imageUrl: item.type === 'image' ? localImage : null,
                          videoUrl: item.type === 'video' ? localImage : null,
                          isLocalOnly: true 
                      };
                  }
              }
              return item;
          }));
          setHistory(mergedHistory);
          if (mergedHistory.length > 0) setCarouselIndex(0);
      } catch (e) { console.error("Failed to load history", e); } finally { setIsHistoryLoading(false); }
  };
  
  const currentHistory = history.filter(item => item.type === view);
  const uniqueTopics = Array.from(new Set(currentHistory.map(item => item.topic).filter(Boolean)));
  const uniqueCampaigns = Array.from(new Set(currentHistory.map(item => item.campaign).filter(Boolean)));
  const filteredHistory = currentHistory.filter(item => {
      const searchMatch = !searchTerm || item.prompt.toLowerCase().includes(searchTerm.toLowerCase());
      const topicMatch = !filterTopic || item.topic === filterTopic;
      const campaignMatch = !filterCampaign || item.campaign === filterCampaign;
      return searchMatch && topicMatch && campaignMatch;
  });

  useEffect(() => { setCarouselIndex(0); setError(null); setSuccessMsg(null); setSearchTerm(''); setFilterTopic(''); setFilterCampaign(''); }, [view]);

  const processAndSetImage = useCallback((file: File, setter: React.Dispatch<React.SetStateAction<ImageState>>, isForImageStudio: boolean) => {
    if (!file.type.startsWith('image/')) { setError('Pasted content is not a valid image file.'); return; }
    const reader = new FileReader();
    reader.onloadend = () => {
        if (reader.result) {
            const dataUrl = reader.result as string;
            setter({ file: file, dataUrl: dataUrl });
            setError(null);
            if (isForImageStudio) { setImageMode('edit'); setSuggestions([]); }
        } else { setError('Failed to read image data from pasted file.'); }
    };
    reader.onerror = () => { setError('Failed to read the pasted image.'); }
    reader.readAsDataURL(file);
  }, [setError, setSuggestions, setImageMode]);

  const pasteHandlerRef = useRef<(event: ClipboardEvent) => void>();
  useEffect(() => {
    pasteHandlerRef.current = (event: ClipboardEvent) => {
      const items = event.clipboardData?.items;
      if (!items) return;
      const imageItem = Array.from(items).find(item => item.type.startsWith('image/'));
      if (imageItem) {
        const file = imageItem.getAsFile();
        if (file) {
          event.preventDefault();
          if (view === 'image') { processAndSetImage(file, setOriginalImage, true); }
          else if (view === 'video') { processAndSetImage(file, setStartImage, false); }
        }
      }
    };
  });
  useEffect(() => {
    const handlePaste = (event: ClipboardEvent) => { if (pasteHandlerRef.current) { pasteHandlerRef.current(event); } };
    document.addEventListener('paste', handlePaste);
    return () => { document.removeEventListener('paste', handlePaste); };
  }, []);

  const checkApiKey = async () => { const hasKey = await window.aistudio.hasSelectedApiKey(); setIsApiKeySelected(hasKey); };
  const handleSelectKey = async () => { await window.aistudio.openSelectKey(); setIsApiKeySelected(true); setError(null); };
  const resetImageState = () => { setOriginalImage({ file: null, dataUrl: null }); setUserInput(''); setSuggestions([]); setSelectedTemplate(null); };
  const handleImageModeChange = (newMode: ImageMode) => { setImageMode(newMode); if (newMode === 'edit') setIsManualMode(true); resetImageState(); setError(null); setSuccessMsg(null); };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve((reader.result as string).split(',')[1]);
      reader.onerror = (error) => reject(error);
    });
  };

  const handleApiError = (e: any) => {
    console.error(e);
    const errorMessage = e instanceof Error ? e.message : "An unknown error occurred.";
    if (errorMessage.includes("403") || errorMessage.includes("PERMISSION_DENIED")) { setError("Permission Denied: These models require a paid API key."); setIsApiKeySelected(false); } else { setError(\`Generation failed: \${errorMessage}\`); }
  };

  const autoSaveToAirtable = async (item: HistoryItem): Promise<string | null> => {
    if (airtableConfig.apiKey && airtableConfig.baseId) {
        setIsSavingToAirtable(true);
        if (airtableConfig.imgbbApiKey) { setSuccessMsg("Bridging image to cloud... (Check ad-blockers if this fails)"); } else { setSuccessMsg("Saving metadata..."); }
        try {
            const newRecordId = await saveRecordToAirtable(airtableConfig, {
                prompt: item.prompt,
                type: item.type,
                topic: item.topic,
                campaign: item.campaign,
                style: item.metadata?.style,
                layout: item.metadata?.layout,
                aspectRatio: item.aspectRatio,
                resolution: item.resolution,
                isFavorite: item.isFavorite,
                imageData: item.imageUrl, 
                lighting: item.metadata?.lighting,
                camera: item.metadata?.camera,
                rawInput: item.metadata?.rawInput,
                creativeDirection: item.metadata?.creativeDirection,
                templateId: item.metadata?.templateId
            });
            setSuccessMsg(airtableConfig.imgbbApiKey ? "Success! Image bridged to Airtable." : "Metadata saved. Image stored locally.");
            return newRecordId;
        } catch (e: any) { console.error("Auto-save failed", e); setError(\`Airtable Sync Issues: \${e.message}\`); } finally { setIsSavingToAirtable(false); }
    }
    return null;
  };

  const handleGenerateImage = async () => {
    const promptToUse = finalPrompt;
    if (imageMode === 'edit' && (!originalImage.file || !promptToUse.trim())) { setError("Please upload an image and provide an editing prompt."); return; }
    if (imageMode === 'generate' && !promptToUse.trim()) { setError("Please provide a prompt to generate an image."); return; }
    setIsLoading(true); setError(null); setSuccessMsg(null); setSuggestions([]);

    try {
      let resultImageUrl: string;
      if (imageMode === 'edit' && originalImage.file) {
        const base64String = await fileToBase64(originalImage.file);
        resultImageUrl = await editImageWithPrompt(base64String, originalImage.file.type, promptToUse, imageAspectRatio, imageResolution);
      } else {
        resultImageUrl = await generateImageFromPrompt(promptToUse, imageAspectRatio, imageResolution);
      }
      
      const tempId = \`temp-\${Date.now()}\`;
      const newHistoryItem: HistoryItem = {
        id: tempId,
        type: 'image',
        topic: topic.trim() || 'General',
        campaign: campaign.trim() || 'Uncategorized',
        isFavorite: false,
        imageUrl: resultImageUrl,
        prompt: promptToUse, 
        aspectRatio: imageAspectRatio,
        resolution: imageResolution,
        isLocalOnly: true,
        metadata: {
            style: isManualMode ? 'Manual' : visualStyle,
            layout: layoutStyle,
            lighting: lighting,
            camera: camera,
            rawInput: userInput,
            creativeDirection: creativeDirectionPrompt,
            templateId: selectedTemplate?.id
        }
      };
      
      setHistory(prev => [newHistoryItem, ...prev]);
      setCarouselIndex(0); 
      const realRecordId = await autoSaveToAirtable(newHistoryItem);
      const finalId = realRecordId || tempId;
      await saveLocalImage(finalId, resultImageUrl);
      if (realRecordId) { setHistory(prev => prev.map(item => item.id === tempId ? { ...item, id: realRecordId } : item)); }

    } catch (e) { handleApiError(e); } finally { setIsLoading(false); }
  };

  const handleGenerateVideo = async () => {
      let promptToUse = videoPrompt;
      if (!promptToUse.trim()) { setError("Video prompt required."); return; }
      setIsLoading(true); setError(null); setLoadingMessage("Initializing...");
      try {
        let startImagePayload = null;
        if (startImage.file) { startImagePayload = { mimeType: startImage.file.type, data: await fileToBase64(startImage.file) } }
        const videoUrl = await generateVideoFromPrompt(promptToUse, setLoadingMessage, startImagePayload, videoAspectRatio, videoResolution);
        const tempId = \`temp-\${Date.now()}\`;
        const newHistoryItem: HistoryItem = {
          id: tempId,
          type: 'video',
          topic: topic.trim() || 'General',
          campaign: campaign.trim() || 'Uncategorized',
          isFavorite: false,
          imageUrl: startImage.dataUrl || null,
          videoUrl: videoUrl,
          prompt: promptToUse,
          aspectRatio: videoAspectRatio,
          resolution: videoResolution,
          isLocalOnly: true,
          metadata: { style: isManualMode ? 'Manual' : 'Video' }
        };
        setHistory(prev => [newHistoryItem, ...prev]);
        setCarouselIndex(0);
        const realRecordId = await autoSaveToAirtable(newHistoryItem);
        const finalId = realRecordId || tempId;
        if (realRecordId) { setHistory(prev => prev.map(item => item.id === tempId ? { ...item, id: realRecordId } : item)); }
      } catch(e) { handleApiError(e); } finally { setIsLoading(false); setLoadingMessage(''); }
  };

  const toggleFavorite = (itemId: string) => { setHistory(prev => prev.map(item => item.id === itemId ? { ...item, isFavorite: !item.isFavorite } : item)); };

  const downloadFavorites = async () => {
    const faves = history.filter(h => h.isFavorite && (h.imageUrl || h.videoUrl));
    if (faves.length === 0) { setError("No favorites found to download."); return; }
    setSuccessMsg(\`Downloading \${faves.length} favorites... check your downloads folder.\`);
    for (let i = 0; i < faves.length; i++) {
        const item = faves[i];
        const link = document.createElement('a');
        const url = item.type === 'image' ? item.imageUrl! : item.videoUrl!;
        const ext = item.type === 'image' ? 'png' : 'mp4';
        const filename = \`fav_\${item.topic.replace(/\\s+/g,'_')}_\${item.id}.\${ext}\`;
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        await new Promise(r => setTimeout(r, 800));
    }
  };
  
  const handleRemix = async (item: HistoryItem) => {
      setSuccessMsg(null);
      if (item.type === 'image') {
          if (item.topic) setTopic(item.topic);
          if (item.campaign) setCampaign(item.campaign);
          if (item.aspectRatio) setImageAspectRatio(item.aspectRatio as any);
          if (item.resolution) setImageResolution(item.resolution as any);
          const meta = item.metadata || {};
          if (meta.rawInput) {
              setUserInput(meta.rawInput);
              setIsManualMode(false);
              setVisualStyle(meta.style || '');
              setLayoutStyle(meta.layout || '');
              setLighting(meta.lighting || '');
              setCamera(meta.camera || '');
              setCreativeDirectionPrompt(meta.creativeDirection || '');
              setSelectedTemplate(null); 
          } else {
              setUserInput(item.prompt); 
              setIsManualMode(true);
          }
          setSuggestions([]); setImageMode('generate'); setView('image');
      }
      const inputElement = document.getElementById('input-panel');
      inputElement?.scrollIntoView({ behavior: 'smooth' });
  };
  
  const handleTemplateSelect = (template: PromptTemplate) => { setSelectedTemplate(template); setIsManualMode(false); };
  const handleCopyToManual = () => { setUserInput(finalPrompt); setIsManualMode(true); setSelectedTemplate(null); setCreativeDirectionPrompt(''); };
  const nextItem = () => { if (carouselIndex < currentHistory.length - 1) setCarouselIndex(prev => prev + 1); };
  const prevItem = () => { if (carouselIndex > 0) setCarouselIndex(prev => prev - 1); };
  const isImageButtonDisabled = isLoading || !finalPrompt.trim() || (imageMode === 'edit' && !originalImage.file) || !isApiKeySelected;
  const isVideoButtonDisabled = isLoading || !finalPrompt.trim() || !isApiKeySelected;
  const ApiKeyOverlay = () => (
    <div className="flex flex-col items-center justify-center text-center p-8 bg-gray-900/50 rounded-lg border border-gray-700">
      <h3 className='text-xl font-semibold text-white'>API Key Required</h3>
      <button onClick={handleSelectKey} className="mt-4 bg-primary hover:bg-primary-hover text-white font-bold py-3 px-6 rounded-lg shadow-lg">Select API Key</button>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col items-center p-4 sm:p-6 lg:p-8 relative">
      <SettingsModal isOpen={showSettings} onClose={() => setShowSettings(false)} config={airtableConfig} onSave={handleSaveSettings} history={history} />
      <TemplateLibraryModal isOpen={showTemplateLibrary} onClose={() => setShowTemplateLibrary(false)} onSelectTemplate={handleTemplateSelect} config={airtableConfig} />
      <ControlManagerModal isOpen={showControlManager} onClose={() => setShowControlManager(false)} config={airtableConfig} onUpdate={() => loadDynamicControls(airtableConfig)} />
      <button onClick={() => setShowSettings(true)} className="fixed top-4 right-4 z-50 text-gray-300 hover:text-white p-2 bg-gray-800/80 rounded-full shadow-lg border border-gray-600/50"><Icon name="settings" className="w-6 h-6" /></button>
      <header className="w-full max-w-6xl flex justify-center items-center mb-8">
        <div className="text-center">
            <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary-light to-primary">Gemini Presentation Studio</h1>
            <p className="mt-2 text-lg text-gray-400">Professional asset generator.</p>
        </div>
      </header>
      <div className="w-full max-w-xs mb-8 flex justify-center">
        <div className="bg-gray-800 p-1 rounded-lg inline-flex items-center space-x-1 border border-gray-700">
          <button onClick={() => setView('image')} className={\`px-6 py-2 rounded-md text-sm font-medium transition-all \${view === 'image' ? 'bg-primary text-white shadow-lg' : 'text-gray-400 hover:text-white'}\`}>Image Studio</button>
          <button onClick={() => setView('video')} className={\`px-6 py-2 rounded-md text-sm font-medium transition-all \${view === 'video' ? 'bg-primary text-white shadow-lg' : 'text-gray-400 hover:text-white'}\`}>Video Studio</button>
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 w-full max-w-6xl">
        <div className="lg:col-span-4 space-y-6" id="input-panel">
          <div className="bg-gray-800/80 p-5 rounded-2xl border border-gray-700 backdrop-blur-sm space-y-4">
             <div className="flex items-center justify-between mb-2"><h2 className="text-sm font-bold text-white uppercase tracking-wider">Project Context</h2></div>
             <div className="grid grid-cols-2 gap-3">
                 <div><input type="text" value={topic} onChange={(e) => setTopic(e.target.value)} placeholder="Topic (e.g. Q3 Financials)" className="w-full bg-gray-900 border border-gray-600 rounded-lg px-2 py-2 text-sm text-white focus:ring-1 focus:ring-primary outline-none" /></div>
                 <div><input type="text" value={campaign} onChange={(e) => setCampaign(e.target.value)} placeholder="Campaign (e.g. Social)" className="w-full bg-gray-900 border border-gray-600 rounded-lg px-2 py-2 text-sm text-white focus:ring-1 focus:ring-primary outline-none" /></div>
             </div>
          </div>
          {view === 'image' && (
            <div className="bg-gray-800/80 p-5 rounded-2xl border border-gray-700 backdrop-blur-sm space-y-5">
              <div className="flex border-b border-gray-700 pb-1">
                <button onClick={() => handleImageModeChange('generate')} className={\`flex-1 pb-3 text-sm font-medium transition-colors \${imageMode === 'generate' ? 'text-primary border-b-2 border-primary' : 'text-gray-400'}\`}>Generate</button>
                <button onClick={() => handleImageModeChange('edit')} className={\`flex-1 pb-3 text-sm font-medium transition-colors \${imageMode === 'edit' ? 'text-primary border-b-2 border-primary' : 'text-gray-400'}\`}>Edit / Remix</button>
              </div>
              {imageMode === 'generate' && !isManualMode && (
                  <>
                     <div className="bg-gray-900/40 p-3 rounded-lg border border-gray-700/50 space-y-3 relative group">
                         <div className="flex justify-between items-center">
                             <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Studio Controls</h3>
                             <button onClick={() => setShowControlManager(true)} className="text-[10px] text-primary hover:text-white underline">Manage Options</button>
                         </div>
                         <div className="grid grid-cols-2 gap-2">
                             <ControlSelect label="Layout Type" value={layoutStyle} onChange={setLayoutStyle} options={layouts} />
                             <ControlSelect label="Visual Style" value={visualStyle} onChange={setVisualStyle} options={styles} />
                         </div>
                         <div className="grid grid-cols-2 gap-2">
                             <ControlSelect label="Lighting" value={lighting} onChange={setLighting} options={lightingOpts} />
                             <ControlSelect label="Camera/Lens" value={camera} onChange={setCamera} options={cameraOpts} />
                         </div>
                     </div>
                     <div className="bg-primary/10 border border-primary/30 p-3 rounded-lg flex items-center justify-between">
                         <div className="overflow-hidden mr-2">
                             <span className="block text-[10px] text-primary-light font-bold uppercase tracking-wider">Active Prompt Structure</span>
                             <span className="block text-sm text-white truncate font-medium">{selectedTemplate ? selectedTemplate.title : "Freeform (No Template)"}</span>
                         </div>
                         <button onClick={() => setShowTemplateLibrary(true)} className="text-xs bg-primary hover:bg-primary-hover text-white px-3 py-1.5 rounded-md font-bold whitespace-nowrap transition-colors">Change</button>
                     </div>
                  </>
              )}
              {imageMode === 'edit' && (
                <div className="h-40">
                  <ImageDropzone imageState={originalImage} onFileSelect={(file) => processAndSetImage(file, setOriginalImage, true)} onRemove={() => setOriginalImage({ file: null, dataUrl: null })} placeholderLabel="Upload to Edit" />
                </div>
              )}
              <div>
                <div className="flex justify-between items-center mb-2">
                   <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">{imageMode === 'generate' && !isManualMode ? 'Content Description' : 'Full Manual Prompt'}</label>
                   {isManualMode && <button onClick={() => setIsManualMode(false)} className="text-[10px] text-primary hover:text-white underline">Reset to Auto</button>}
                </div>
                <textarea value={userInput} onChange={(e) => setUserInput(e.target.value)} placeholder={imageMode === 'generate' && !isManualMode ? "e.g. Sales growth of 20% in Q3..." : "Describe exactly what you want..."} className="w-full h-24 bg-gray-900 border border-gray-600 rounded-lg p-3 text-sm text-white focus:ring-2 focus:ring-primary outline-none resize-none" />
              </div>
              {imageMode === 'generate' && !isManualMode && ( <CreativeDirectionManager config={airtableConfig} selectedThemePrompt={creativeDirectionPrompt} onSelect={setCreativeDirectionPrompt} /> )}
              {imageMode === 'generate' && !isManualMode && (
                  <div className="bg-black/40 rounded-lg p-3 border border-gray-700/50">
                      <div className="flex justify-between items-center mb-1"><span className="text-[10px] uppercase text-gray-500 font-bold flex items-center gap-1"><Icon name="sparkles" className="w-3 h-3" /> Synthesized Prompt</span><button onClick={handleCopyToManual} className="text-[10px] text-primary hover:text-white underline">Edit Manually</button></div>
                      <p className="text-xs text-gray-300 italic leading-relaxed opacity-90 border-l-2 border-primary pl-2">"{finalPrompt}"</p>
                  </div>
              )}
              <div className="flex gap-2 flex-wrap bg-gray-900/50 p-3 rounded-lg border border-gray-700/50 justify-between">
                   <ControlSelect label="Aspect Ratio" value={imageAspectRatio} onChange={(v) => setImageAspectRatio(v as any)} options={[{value:'1:1',label:'1:1'},{value:'16:9',label:'16:9'},{value:'9:16',label:'9:16'},{value:'4:3',label:'4:3'}]} />
                   <ControlSelect label="Resolution" value={imageResolution} onChange={(v) => setImageResolution(v as any)} options={[{value:'1K',label:'1K'},{value:'2K',label:'2K'},{value:'4K',label:'4K'}]} />
              </div>
              {!isApiKeySelected ? <ApiKeyOverlay /> : (
                <button onClick={handleGenerateImage} disabled={isImageButtonDisabled} className={\`w-full py-3 rounded-lg font-bold text-white shadow-lg transition-all transform hover:scale-[1.02] flex items-center justify-center gap-2 \${isImageButtonDisabled ? 'bg-gray-700 cursor-not-allowed text-gray-400' : 'bg-gradient-to-r from-primary to-purple-600 hover:from-primary-hover hover:to-purple-500'}\`}>
                  {isLoading ? <Spinner /> : <Icon name="sparkles" className="w-5 h-5" />}
                  {isLoading ? 'Processing...' : imageMode === 'generate' ? 'Generate Asset' : 'Edit Image'}
                </button>
              )}
            </div>
          )}
          {view === 'video' && (
             <div className="bg-gray-800/80 p-5 rounded-2xl border border-gray-700 backdrop-blur-sm space-y-6">
               <textarea value={videoPrompt} onChange={(e) => setVideoPrompt(e.target.value)} placeholder="Describe video..." className="w-full h-32 bg-gray-900 border border-gray-600 rounded-lg p-3 text-sm text-white focus:ring-2 focus:ring-primary outline-none resize-none" />
               {!isApiKeySelected ? <ApiKeyOverlay /> : (<button onClick={handleGenerateVideo} disabled={isVideoButtonDisabled} className="w-full py-3 rounded-lg font-bold text-white bg-blue-600">Generate Video</button>)}
             </div>
          )}
        </div>
        <div className="lg:col-span-8 flex flex-col space-y-6">
           <div className="flex-grow bg-gray-800 rounded-2xl border border-gray-700 overflow-hidden min-h-[500px] flex flex-col relative">
              {(error || successMsg) && <div className={\`w-full p-3 text-sm text-center \${error ? 'bg-red-900/50 text-red-200' : 'bg-green-900/50 text-green-200'}\`}>{error || successMsg}</div>}
              <div className="flex-1 flex items-center justify-center p-8 bg-gray-900/50 relative">
                 {isLoading ? (
                    <div className="text-center"><Spinner /><p className="text-gray-400 animate-pulse mt-4">Creating...</p></div>
                 ) : currentHistory.length > 0 ? (
                    <div className="w-full h-full flex flex-col items-center">
                       <div className="relative w-full flex-1 flex items-center justify-center">
                          {currentHistory[carouselIndex].type === 'image' && currentHistory[carouselIndex].imageUrl ? (
                            <img src={currentHistory[carouselIndex].imageUrl!} className="max-w-full max-h-[500px] object-contain rounded-lg shadow-2xl" />
                          ) : (
                             <div className="flex flex-col items-center text-center p-10 bg-gray-800/50 border-2 border-dashed border-gray-600 max-w-lg">
                                <Icon name="image" className="w-16 h-16 text-gray-600 mb-4" />
                                <h3 className="text-xl font-bold text-gray-300 mb-2">Image Not Loaded</h3>
                                <p className="text-gray-400 mb-6">Upload to 'Attachments' in Airtable.</p>
                             </div>
                          )}
                       </div>
                    </div>
                 ) : ( <div className="text-center text-gray-500"><p>No content found.</p></div> )}
              </div>
              {currentHistory.length > 0 && !isLoading && (
                 <div className="p-4 bg-gray-800 border-t border-gray-700 flex justify-between items-center">
                    <div className="flex gap-2">
                        <button onClick={() => toggleFavorite(currentHistory[carouselIndex].id)} className={\`p-2 rounded-lg transition-colors \${currentHistory[carouselIndex].isFavorite ? 'bg-red-500/20 text-red-400' : 'bg-gray-700 text-gray-400 hover:text-white'}\`}>
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" /></svg>
                        </button>
                        <button onClick={() => handleRemix(currentHistory[carouselIndex])} className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg text-sm font-medium">Remix / Edit</button>
                    </div>
                    <div className="flex gap-2">
                        <button onClick={downloadFavorites} className="px-4 py-2 bg-green-700 hover:bg-green-600 text-white rounded-lg text-sm font-bold flex items-center gap-2">Download Favorites</button>
                        {(currentHistory[carouselIndex].imageUrl || currentHistory[carouselIndex].videoUrl) && ( <a href={currentHistory[carouselIndex].type === 'image' ? currentHistory[carouselIndex].imageUrl! : currentHistory[carouselIndex].videoUrl!} download className="px-4 py-2 bg-primary text-white rounded-lg font-bold">Download</a> )}
                    </div>
                 </div>
              )}
           </div>
           <div className="flex flex-col gap-4">
               <div className="flex justify-between items-center"><h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider">History & Filters</h3><button onClick={() => loadHistory(airtableConfig)} className="text-xs text-primary hover:text-white flex items-center gap-1"><Icon name="sparkles" className="w-3 h-3"/> Refresh</button></div>
               <div className="flex flex-wrap gap-2 bg-gray-800/50 p-3 rounded-xl border border-gray-700">
                    <div className="flex-1 min-w-[200px]"><input type="text" placeholder="Search prompt content..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-sm text-white focus:border-primary outline-none" /></div>
                    <div className="w-40"><select value={filterTopic} onChange={(e) => setFilterTopic(e.target.value)} className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-sm text-gray-300 focus:border-primary outline-none"><option value="">All Topics</option>{uniqueTopics.map(t => <option key={t} value={t}>{t}</option>)}</select></div>
                    <div className="w-40"><select value={filterCampaign} onChange={(e) => setFilterCampaign(e.target.value)} className="w-full bg-gray-900 border border-gray-600 rounded px-3 py-2 text-sm text-gray-300 focus:border-primary outline-none"><option value="">All Campaigns</option>{uniqueCampaigns.map(c => <option key={c} value={c}>{c}</option>)}</select></div>
                    {(searchTerm || filterTopic || filterCampaign) && (<button onClick={() => { setSearchTerm(''); setFilterTopic(''); setFilterCampaign(''); }} className="bg-gray-700 hover:bg-gray-600 text-gray-300 px-3 py-2 rounded text-sm">Reset</button>)}
               </div>
               {filteredHistory.length > 0 ? ( <HistoryFeed history={filteredHistory} onSelect={(item) => { const index = currentHistory.findIndex(i => i.id === item.id); if(index !== -1) setCarouselIndex(index); }} /> ) : ( <div className="p-8 border border-dashed border-gray-700 rounded-2xl text-center text-gray-500">{currentHistory.length > 0 ? "No matches found." : "History is empty"}</div> )}
           </div>
        </div>
      </div>
    </div>
  );
};
export default App;`,
};

// Create directories and write files
Object.keys(files).forEach(filePath => {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir) && dir !== '.') {
    fs.mkdirSync(dir, { recursive: true });
  }
  fs.writeFileSync(filePath, files[filePath]);
  console.log('Created: ' + filePath);
});

console.log('Setup complete! Run "npm install" then "npm run dev" to start.');
